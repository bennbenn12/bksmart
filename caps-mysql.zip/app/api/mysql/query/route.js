import { NextResponse } from 'next/server'
import { cookies } from 'next/headers'
import { executePayload } from '@/lib/mysql/supabaseCompat'
import { verifySessionToken, getSessionCookieName } from '@/lib/mysql/session'

export async function POST(request) {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(getSessionCookieName())?.value
    const session = verifySessionToken(token)

    if (!session) {
      return NextResponse.json({ data: null, error: { message: 'Unauthorized' } }, { status: 401 })
    }

    const payload = await request.json()
    const { table, action } = payload
    const isAdmin = ['bookstore_manager', 'bookstore_staff'].includes(session.role)

    if (!isAdmin) {
      if (action === 'delete') {
        return NextResponse.json({ data: null, error: { message: 'Forbidden' } }, { status: 403 })
      }
      
      const publicSelects = ['bookstore_items', 'appointment_slots']
      const userSelects = ['users', 'orders', 'order_items', 'appointments', 'feedback', 'queues', 'notifications']
      
      if (action === 'select' && !publicSelects.includes(table) && !userSelects.includes(table)) {
        return NextResponse.json({ data: null, error: { message: 'Forbidden' } }, { status: 403 })
      }

      if (action === 'select' && userSelects.includes(table)) {
        payload.filters = payload.filters || []
        if (table === 'users') {
          payload.filters.push({ op: 'eq', column: 'auth_id', value: session.sub })
        } else {
          payload.filters.push({ op: 'eq', column: 'user_id', value: session.user_id })
        }
      }

      const allowedWrites = ['orders', 'order_items', 'appointments', 'feedback', 'queues', 'notifications']
      if (action === 'insert' || action === 'update') {
        if (!allowedWrites.includes(table)) {
          return NextResponse.json({ data: null, error: { message: 'Forbidden' } }, { status: 403 })
        }
        
        if (action === 'insert') {
          const rows = Array.isArray(payload.values) ? payload.values : [payload.values]
          rows.forEach(r => {
             if (table !== 'users') r.user_id = session.user_id
          })
          payload.values = Array.isArray(payload.values) ? rows : rows[0]
        }
        
        if (action === 'update') {
          payload.filters = payload.filters || []
          payload.filters.push({ op: 'eq', column: 'user_id', value: session.user_id })
          if (payload.values && payload.values.user_id) delete payload.values.user_id
        }
      }
    }

    const result = await executePayload(payload)
    if (payload.single) {
      const row = Array.isArray(result.data) ? (result.data[0] || null) : result.data
      return NextResponse.json({ ...result, data: row })
    }
    return NextResponse.json(result)
  } catch (error) {
    return NextResponse.json({ data: null, error: { message: error.message || 'Query failed' } }, { status: 500 })
  }
}
